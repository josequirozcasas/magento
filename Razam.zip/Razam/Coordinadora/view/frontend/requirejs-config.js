var config = {
    "map": {
        "*": {
            "Magento_OfflineShipping/js/model/shipping-rates-validation-rules/coordinadora": "Razam_Coordinadora/js/model/shipping-rates-validation-rules",
        }
    }
};
